package modulo2.practica04;

public class PC {
	private String marca;
	private String modelo;
	private int ram;
	private int hd;
	
	public PC() {
		super();
		this.marca = null;
		this.modelo = null;
		this.ram = 0;
		this.hd = 0;
	}

	public PC(String marca, String modelo, int ram, int hd) {
		super();
		this.marca = marca;
		this.modelo = modelo;
		this.ram = ram;
		this.hd = hd;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public int getRam() {
		return ram;
	}

	public void setRam(int ram) {
		this.ram = ram;
	}

	public int getHd() {
		return hd;
	}

	public void setHd(int hd) {
		this.hd = hd;
	}

	@Override
	public String toString() {
		return "PC [marca=" + marca + ", modelo=" + modelo + ", ram=" + ram + ", hd=" + hd + "]";
	}
	
	
}
