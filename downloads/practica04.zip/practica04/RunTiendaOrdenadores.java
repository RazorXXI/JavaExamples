package modulo2.practica04;

import java.util.ArrayList;
import java.util.Scanner;

public class RunTiendaOrdenadores {

	public static void main(String[] args) {
		String opcString; //Para leer la opcion elegida del men�
		String marca;
		String modelo;
		int ram;
		int hd;
		ArrayList<PC> ordenadoresArrayList = new ArrayList<>();
				
		try (Scanner sc = new Scanner(System.in)) {
			do {

				GestionTienda.mostrarMenu();
				opcString = sc.nextLine().toLowerCase();
				
				switch (opcString) {
				case "1"://Configurar Nuevo PC
					System.out.println("Configurador PC");
					System.out.println("---------------");
					System.out.print("Indique la marca: ");
					marca = sc.nextLine().toUpperCase();
					System.out.print("Indique el modelo: ");
					modelo = sc.nextLine().toUpperCase();
					System.out.print("Indique cantidad de RAM (Gb): ");
					ram = sc.nextInt();
					System.out.print("Indique capacidad de Disco Duro (Gb): ");
					hd = sc.nextInt();
					
					ordenadoresArrayList.add(new PC(marca, modelo, ram, hd));
					
					System.out.println("Presione INTRO para volver al menu...");
					opcString = sc.nextLine();
					sc.nextLine(); //Necesario para limpiar el buffer de Scanner y que no me duplique
					break;
				case "2"://Modificar PC
					System.out.println("Modificaci�n en PC");
					System.out.println("------------------");
					System.out.print("Indique Modelo a Modificar: ");
					modelo = sc.nextLine().toUpperCase();
					
					PC pc = ordenadoresArrayList.get(ordenadoresArrayList.indexOf(modelo));
					
					if (pc == null) {
						System.out.println("No existe el modelo a modificar");
					}
					else {
						System.out.println("El ordenador elegido es: " + pc.getMarca() + " Modelo " + pc.getModelo());
					}
					System.out.println("Presione INTRO para volver al menu...");
					opcString = sc.nextLine();
					sc.nextLine(); //Necesario para limpiar el buffer de Scanner y que no me duplique
					break;
				case "3"://Eliminar PC
					break;
				case "4"://Mostar datos de un PC
					break;
				case "5"://Listar todos los PCs
					break;
				case "0": case "salir":
					break;
				default:
					System.out.println("La opcion seleccionada no es valida!!");
				}
			} while (!opcString.equals("salir") && !opcString.equals("0"));
			sc.close();
		}
		System.out.println("Finalizando el programa!!");
	}
}

class GestionTienda {
	
	static void mostrarMenu() {
		System.out.println("------ GESTION DE TIENDA ------");
		System.out.println("1 - Configurar Nuevo PC");
		System.out.println("2 - Modificar PC");
		System.out.println("3 - Dar de Baja PC");
		System.out.println("4 - Mostrar datos de un PC");
		System.out.println("5 - Mostrar todos los PC");
		System.out.println("0 - Salir de la aplicaci�n");
		System.out.println("-------------------------------");
		System.out.println("Seleccione una Opcion: ");
	}
}
