package modulo2.practica04;

import java.util.*;
import java.io.*;

public class RunTiendaOrdenadores {

	public static void main(String[] args) {
		String opcString; //Para leer la opcion elegida del men�
		String modelo;
		int indice;
		
		List<PC> ordenadoresArrayList = new ArrayList<>();
				
		try (Scanner sc = new Scanner(System.in)) {
			do {

				GestionTienda.mostrarMenu();
				opcString = sc.nextLine().toLowerCase();
				
				switch (opcString) {
				case "1"://Configurar Nuevo PC
					PC pc;
					pc = GestionTienda.subMenuNuevoPc();
					ordenadoresArrayList.add(pc);				
					
					System.out.println("Presione INTRO para volver al menu...");
					opcString = sc.nextLine();				
					
					break;
				case "2"://Modificar PC
					System.out.println("Modificacion en PC");
					System.out.println("------------------");
					System.out.print("Indique Modelo a Modificar: ");
					modelo = sc.nextLine().toUpperCase();
					
					indice = GestionTienda.buscarElemento(modelo, ordenadoresArrayList);
					
					if(indice >= 0) {
						GestionTienda.modificarOrdenador(indice, ordenadoresArrayList);
					}
					else {
						System.out.println("El modelo buscado no existe...");
					}
					
					System.out.println("Presione INTRO para volver al menu...");
					opcString = sc.nextLine();
					
					break;
				case "3"://Eliminar PC
					System.out.println("Eliminar un PC");
					System.out.println("------------------");
					System.out.print("Indique Modelo a Eliminar: ");
					modelo = sc.nextLine().toUpperCase();
					
					indice = GestionTienda.buscarElemento(modelo, ordenadoresArrayList);
					
					if (indice >= 0) {
						System.out.println("Se va a proceder a eliminar un PC. Desea continuar (Y/N): ");
						opcString = sc.nextLine().toUpperCase();
						if (opcString.equals("Y")) {
							ordenadoresArrayList.remove(indice);
							System.out.println("Ordenador Modelo " + modelo + " ha sido eliminado");
						}
						else {
							System.out.println("Cancelada eliminaci�n del " + modelo);
						}
					}
					else {
						System.out.println("El modelo buscado no existe...");
					}
					
					System.out.println("Presione INTRO para volver al menu...");
					opcString = sc.nextLine();

					break;
				case "4"://Mostar datos de un PC
					System.out.println("Mostrar datos de un PC");
					System.out.println("----------------------");
					System.out.print("Indique Modelo a mostrar: ");
					modelo = sc.nextLine().toUpperCase();
					
					indice = GestionTienda.buscarElemento(modelo, ordenadoresArrayList);
					
					if (indice >= 0) {
						System.out.println("Marca: " + ordenadoresArrayList.get(indice).getMarca());
						System.out.println("Modelo: " + ordenadoresArrayList.get(indice).getModelo());
						System.out.println("Memoria RAM: " + ordenadoresArrayList.get(indice).getRam() + " Gb");
						System.out.println("Disco HD: " + ordenadoresArrayList.get(indice).getHd() + " Gb");
						System.out.println();
					}
					else {
						System.out.println("El modelo buscado no existe...");
					}
					
					System.out.println("Presione INTRO para volver al menu...");
					opcString = sc.nextLine();
					
					break;
				case "5"://Listar todos los PCs
					for(PC items: ordenadoresArrayList) {
						System.out.println(items);
					}
					
					System.out.println("Presione INTRO para volver al menu...");
					opcString = sc.nextLine();
					
					break;
				case "0": case "salir":
					break;
				default:
					System.out.println("La opcion seleccionada no es valida!!");
				}
			} while (!opcString.equals("salir") && !opcString.equals("0"));
			sc.close();
		}
		System.out.println("Finalizando el programa!!");
	}
}

class GestionTienda {
	
	static void mostrarMenu() {
		System.out.println("------ GESTION DE TIENDA ------");
		System.out.println("1 - Configurar Nuevo PC");
		System.out.println("2 - Modificar PC");
		System.out.println("3 - Dar de Baja PC");
		System.out.println("4 - Mostrar datos de un PC");
		System.out.println("5 - Mostrar todos los PC");
		System.out.println("0 - Salir de la aplicacion");
		System.out.println("-------------------------------");
		System.out.println("Seleccione una Opcion: ");
	}
	
	static PC subMenuNuevoPc() {
		Scanner sc = new Scanner(System.in);
		String marca;
		String modelo;
		int ram;
		int hd;
		try {
			System.out.println("Configurador PC");
			System.out.println("---------------");
			System.out.print("Indique la marca: ");
			marca = sc.nextLine().toUpperCase();
			System.out.print("Indique el modelo: ");
			modelo = sc.nextLine().toUpperCase();
			System.out.print("Indique cantidad de RAM (Gb): ");
			ram = sc.nextInt();
			System.out.print("Indique capacidad de Disco Duro (Gb): ");
			hd = sc.nextInt();
		
			PC pc = new PC(marca, modelo, ram, hd);
			
			return pc;
		}
		catch (InputMismatchException ex) {
			System.out.println("El dato introducido no es valido... " + ex.toString());
			return null;
		}
	}
	
	static int buscarElemento(String modelo, List<PC> pcs) {
		int indice = -1;
		
		for(PC item: pcs) {
			if(item.getModelo().equals(modelo)) {
				indice = pcs.indexOf(item);
			break;
			}
		}
		return indice;
	}
	
	static List<PC> modificarOrdenador(int indice, List<PC> listaPcs) {
		PC pc;
		Scanner sc = new Scanner(System.in);
		int ram;
		int hd;
		
		try {
			pc = listaPcs.get(indice);
			listaPcs.remove(indice);
		
			System.out.print("Indique nuevo valor de RAM: ");
			ram = sc.nextInt();
			System.out.print("Indique nuevo valor de HD: ");
			hd = sc.nextInt();
		
			pc.setRam(ram);
			pc.setHd(hd);
		
			listaPcs.add(indice, pc);
		
			return listaPcs;
		}catch (InputMismatchException ex) {
			System.out.println("ERROR: El tipo de dato introducido no es correcto" + ex.toString());
			return null;
		}
	}
}
